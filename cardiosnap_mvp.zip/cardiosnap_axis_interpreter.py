
import streamlit as st
from PIL import Image

st.set_page_config(page_title="CardioSnap Axis Interpretation", layout="centered")

st.title("🫀 CardioSnap™: Axis Interpretation Assistant")

# Step 1: Quick Recap
st.header("Step 1: Quick Recap")
st.markdown("""
**Understanding Axis Interpretation**
- Lead I = Left/Right
- aVF = Up/Down
- Determine quadrant using the net QRS deflection
""")
st.image("https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/ECG_Axis_quadrants.svg/1200px-ECG_Axis_quadrants.svg.png", caption="Axis Quadrant Reference")

st.markdown("---")

# Step 2: ECG Case
st.header("Step 2: Examine the ECG")
st.markdown("Here's a real ECG. Look closely at Lead I and aVF.")
ecg_img = Image.open("Bifascicular_block_ECG.png")
st.image(ecg_img, caption="12‑lead ECG Case")

st.markdown("---")

# Step 3: Interactive Quiz - Lead I
st.header("Step 3: Quiz - Lead I")
st.markdown("**What is the net QRS deflection in Lead I?**")
lead_i = st.radio("Choose one:", ["Positive", "Negative", "Indeterminate"])

if lead_i:
    st.success(f"You selected: {lead_i}")
    lead_i_correct = (lead_i == "Positive")
    st.markdown("---")
    st.header("Step 4: Quiz - aVF")
    lead_avf = st.radio("**What is the net QRS deflection in lead aVF?**", ["Positive", "Negative", "Indeterminate"])

    if lead_avf:
        st.success(f"You selected: {lead_avf}")
        st.markdown("---")
        st.header("Step 5: Interpretation")

        if lead_i_correct and lead_avf == "Negative":
            st.subheader("✅ Likely Left Axis Deviation")
            st.info("Lead I is positive, aVF is negative → Axis is between -30° and -90°")
        elif not lead_i_correct and lead_avf == "Positive":
            st.subheader("✅ Likely Right Axis Deviation")
            st.info("Lead I is negative, aVF is positive → Axis is between +90° and +180°")
        elif not lead_i_correct and lead_avf == "Negative":
            st.subheader("⚠️ Extreme Axis Deviation")
        else:
            st.subheader("✅ Normal Axis")
            st.info("Lead I and aVF both positive → Axis is between 0° and +90°")

        st.markdown("**Want to know why this matters?**")
        if st.button("Explain this diagnosis"):
            st.markdown("""
            - **Left Axis Deviation** may suggest LVH, LBBB, or inferior MI.
            - **Right Axis Deviation** may indicate RVH, PE, or lateral MI.
            - **Extreme axis** is rare but often pathological.
            """)

st.markdown("---")
st.caption("CardioSnap™ ECG Assistant – MVP Edition")
